#!/usr/bin/env python3
"""Check numerical invariants and file provenance of reconstructed outputs."""
from pathlib import Path
import csv, hashlib, json
import numpy as np
ROOT=Path(__file__).resolve().parent
channel=ROOT/'outputs/channels/sylvester_channel_energies.csv'
rows=list(csv.DictReader(channel.open()))
energy=np.array([float(r['energy']) for r in rows]); frac=np.array([float(r['fraction']) for r in rows])
assert np.all(np.isfinite(energy)) and np.all(energy>=0)
assert abs(frac.sum()-1)<1e-11
assert np.max(np.abs(frac-energy/energy.sum()))<1e-11
fig9=list(csv.DictReader((ROOT/'outputs/figure9/figure9_diagnostics.csv').open()))
assert len(fig9)==3
assert all(abs(float(r['lambda1_real'])-float(r['lambda2_real']))<1e-8 for r in fig9)
assert all(float(r['orthogonality_error'])<1e-10 for r in fig9)
assert abs(float(fig9[0]['lambda1_real']))<1e-5
assert abs(float(fig9[-1]['lambda1_real']))>1e-3, 'off-neutral drift should remain disclosed'
files=[x for x in ROOT.rglob('*') if x.is_file() and x.name!='SHA256SUMS.json']
manifest={str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(files)}
(ROOT/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS: channel energy closure and 3-point tracked conjugate packet; off-neutral drift explicitly detected')
print('SHA256 manifest entries:',len(manifest))
