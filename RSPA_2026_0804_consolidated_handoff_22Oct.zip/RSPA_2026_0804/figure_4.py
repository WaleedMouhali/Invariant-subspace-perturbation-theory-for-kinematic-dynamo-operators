#!/usr/bin/env python3
"""Entry point for figure 4; consult FIGURE_REPRODUCIBILITY_MATRIX.md."""
import subprocess,sys
from pathlib import Path
subprocess.run([sys.executable,str(Path(__file__).resolve().parent/'regenerate_figures.py'),'--figure','4',*sys.argv[1:]],check=True)
