# Independent Kmax=4 oscillatory packet check

Command:

```bash
OPENBLAS_NUM_THREADS=1 python validate_k4_packet.py --kmax 4 --rm 8.95117 --omega 0.4 --h 0.001
```

Dimension: 1456. The positive- and negative-frequency conjugate eigenvectors are computed from separate shift-invert spectral searches. The rank-two orthogonal packet is tracked by principal-angle overlap.

At t=-0.001, 0, +0.001 the real parts of the selected eigenvalue were -1.24162372e-6, -3.86199519e-9, -1.24162372e-6, respectively. The centered fixed-Rm growth derivative is 7.985414e-14. Projector chord at either perturbation is 0.0038128215; the corresponding finite-difference Grassmann speed estimate is 3.8128215, consistent with the reported 3.81283.

**Limitations:** This is a fixed-Rm, local packet-tracking check, not a full continuation of Rm_c(t), proof of global spectral dominance, or reproduction of all manuscript figures. Eigenvalue/packet selection relies on the chosen spectral shift and pair matching; inspect and report failures rather than silently selecting a different branch.

Output: `outputs/k4_packet_check.csv`.
