# Reconstructed figure 8/9 diagnostics — 17 October 2026

## Actual new calculations
- `reconstruct_channels.py` computes a *true dense SVD* of the Sylvester response operator for the ABC Fourier-Galerkin truncation **Kmax=2**, Rm=8.95117, direction (A-B)/sqrt(2). The stored CSV contains *all* channel energies. The identity sum(E_j)=||S^-1 F||^2 has relative discrepancy 2.1e-16. **This is not Figure 8 of the submitted manuscript**: its Kmax and Rm differ and the operator is not neutral (the leading real eigenvalue is +0.0411).
- `reconstruct_figure9.py` reconstructs basis-independent packet-averaged spatial magnetic energy using *newly computed* ABC Fourier eigenvectors at **Kmax=3**, Rm=23.8128, z=0, along direction (A-B)/sqrt(2), t={0,0.01,0.02}. The complex-conjugate oscillatory packet is explicitly tracked by proximity to ±0.41302i, avoiding spurious packet swaps in leading-eigenvalue sorting. Eigenvalue real parts at t=0,0.01,0.02 are approximately -2.90e-7, +8.48e-4, +3.386e-3. **This is not an exact reproduction of manuscript Figure 9**, which uses the neutral branch and a specific packet evolution not fully specified by the recovered files.

## Important outstanding work
- Reproduce the manuscript's Figure 8 at its *actual* Kmax=4 and neutral Rm_c, with the same perturbation direction and Sylvester metric. The Kmax=4 Sylvester operator is too large for a naïve dense SVD; use matrix-free singular triplets with adjoint and numerical convergence tests.
- Reproduce Figure 9 along the *actual neutral branch* (recalculate Rm_c(t)), verify spectral packet isolation and track it continuously; ensure the physical-space definition and energy normalisation match the manuscript.
- Independently reproduce the exact numerical experiments behind manuscript Figures 2–5 and the full Kmax=3–6 convergence table.
- All plots under outputs are fresh, illustrative diagnostics; they must not be represented as the original manuscript figures.
