# Tracked neutral branch (18 October 2026)

Command: `OPENBLAS_NUM_THREADS=1 python track_neutral_packet.py --kmax 3 --h 0.001 0.002`

The code uses shift-invert eigenvalues near `0.4i` and selects an oscillatory mode by eigenvalue distance and overlap with the reference eigenvector. Brent root-finding enforces `Re(lambda)=0` on this branch. Results are saved in `outputs/tracked_neutral/tracked_neutral.csv`.

At h=0.001, Rm(+/-h)=23.812132417; at h=0.002, Rm(+/-h)=23.810059114. Centered derivatives are below 2e-11 in magnitude. These data confirm first-order stationarity **for the tracked branch at Kmax=3**, not for the global leading threshold or Kmax=4. The reported local candidate maximum is not a global spectrum audit.

The previous ARPACK `which=LR` attempt failed to converge; shift-invert near 0.4i converged. This is a new reconstructed numerical result, not an exact reproduction of a published figure.

**Remaining:** full competing-spectrum check; Kmax=4/5/6 thresholds and branch tracking; manuscript figure parameter matching; generic figures 2–5 original experimental setup; all-figure clean-room execution.
