# Neutral-branch continuation — independent Kmax=3 check

Run: `OPENBLAS_NUM_THREADS=1 python neutral_branch_continuation.py`

The solver recomputes the first leading-eigenvalue zero in the bracket Rm in [22,26] separately at t=0, 0.01, 0.02 for the direction (A-B)/sqrt(2). These are new calculations, not recovered manuscript data.

Results:

| t | Rm | leading spectral observations |
|---|---:|---|
| 0 | 23.812823619988183 | leading conjugate pair ±0.41301991i, real part ~2.46e-11 |
| .01 | 23.743952584723385 | leading conjugate pair ±0.4133987i, real part ~2.19e-11 |
| .02 | 23.07089068066582 | leading eigenvalue near zero frequency; second eigenvalue -0.0060044 + 0.4182985i |

**CRITICAL:** At t=.02 the leading spectral packet switches character; the two leading eigenvectors no longer form the continuation of the reference conjugate pair. The generated spatial figure therefore displays *leading eigenspaces* at their respective neutral thresholds, not the same continuously tracked invariant packet. Do not label it as a verified reproduction of manuscript Figure 9. The shift of Rm at t=.01 also needs careful analysis against the manuscript's claimed first-order stationarity (possible branch selection and degeneracy issues). Neither the neutrality of the tracked oscillatory pair nor its isolation was verified at t=.02.

The plotted fields and CSV are computational diagnostics. More work is required to track eigenvalues by overlap, identify crossings, and independently check the symmetry argument and derivative.
