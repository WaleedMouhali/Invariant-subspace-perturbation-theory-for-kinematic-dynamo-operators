# Audit of manuscript coverage

| Manuscript component | Status |
|---|---|
| General Grassmann/Sylvester identity | New deterministic small-matrix smoke test (not manuscript Figure 2) |
| ABC Fourier–Galerkin induction operator | Recovered code; basic assembly test |
| ABC neutral threshold | Recovered code; **fresh exact-neutral rerun pending** |
| ABC rank-2 invariant packet | Recovered code; branch/isolation verification pending |
| Figure 7 induction/diffusion | Recovered source, CSV, image; full independent rerun pending |
| Table 1, Kmax 3–6 | **Not reproduced**, earlier K5 value may not be exactly neutral |
| Figures 2–5 controlled tests | **Not reproduced** |
| Figure 6 threshold vs geometry | **Not reproduced** |
| Figure 8 Sylvester singular channels | **Not reproduced** |
| Figure 9 physical-space magnetic reconstruction | **Not reproduced** |
| Figure 1 | Schematic, no numerical data required |

The manuscript should not assert complete independent reproducibility based on this package. No Zenodo DOI exists for this candidate.
