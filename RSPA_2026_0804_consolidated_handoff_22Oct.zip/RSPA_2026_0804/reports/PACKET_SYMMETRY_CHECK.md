# Independent symmetry check (18 October 2026)

Script: `track_packet_symmetry.py`.

At Kmax=3 and fixed Rm=23.812824, an oscillatory eigenvalue was selected at A=B=C=1, and then tracked at A=1+t/sqrt(2), B=1-t/sqrt(2), C=1 by a combined eigenvalue-distance and eigenvector-overlap score. The centered real-eigenvalue derivatives are -1.69e-12 (h=.002) and -3.44e-13 (h=.001); reference eigenvector overlaps exceed 0.99996. This is consistent with first-order stationarity under A/B symmetry.

IMPORTANT: This is not a calculation of the derivative of the critical Rm, nor a proof of uniqueness of the spectral packet. The neutral branch, convergence table, and paper-specific figures remain unverified. A smaller Kmax=2 exploratory test had weaker eigenvector overlaps (~0.913) and should not be used as a continuity demonstration.

Run: `OPENBLAS_NUM_THREADS=1 python track_packet_symmetry.py --kmax 3 --rm 23.812824 --h .002 .001`.
