#!/usr/bin/env python3
"""Reconstruct packet-averaged magnetic energy from freshly solved ABC eigenvectors.
Independent numerical reconstruction; does not claim pixel-exact match to manuscript.
"""
import sys,argparse,csv
from pathlib import Path
import numpy as np
import scipy.linalg as la
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from abc_induction_diffusion_rebuild import build_fourier_system, induction_operator, leading_eigs

def energy(sys,Q,z=0,nxy=85):
    x=np.linspace(0,2*np.pi,nxy,endpoint=False);y=x.copy()
    X,Y=np.meshgrid(x,y,indexing='ij')
    b=np.zeros((nxy,nxy,3,Q.shape[1]),complex)
    for i,k in enumerate(sys.ks):
        coeff=sys.E[k]@Q[2*i:2*i+2,:]
        b+=np.exp(1j*(k[0]*X+k[1]*Y+k[2]*z))[:,:,None,None]*coeff[None,None,:,:]
    return np.sum(np.abs(b)**2,axis=(2,3))/Q.shape[1]

def main():
    p=argparse.ArgumentParser();p.add_argument('--kmax',type=int,default=3);p.add_argument('--rm',type=float,default=23.8128);p.add_argument('--outdir',default='outputs/figure9');args=p.parse_args()
    out=Path(args.outdir);out.mkdir(parents=True,exist_ok=True)
    s=build_fourier_system(args.kmax); direction=np.array([1.,-1.,0.])/np.sqrt(2)
    ts=[0,.01,.02];energies=[];lines=[]
    for t in ts:
        abc=np.ones(3)+t*direction
        op=induction_operator(s,*abc,args.rm)
        vals,vecs=leading_eigs(op,k=12)
        # Follow the reference oscillatory conjugate packet, not the changing leading pair.
        ids=[int(np.argmin(np.abs(vals-1j*.41302))),int(np.argmin(np.abs(vals+1j*.41302)))]
        ev=vals[ids]
        Q,_=la.qr(vecs[:,ids],mode='economic')
        E=energy(s,Q);energies.append(E)
        lines.append((t,ev[0].real,ev[1].real,la.norm(Q.conj().T@Q-np.eye(2))))
        print('t',t,'leading eigenvalues',ev,'mean energy',E.mean(),flush=True)
    fig,axs=plt.subplots(2,3,figsize=(12,7),constrained_layout=True)
    ref=energies[0];scale=max(np.max(a) for a in energies)
    delta=max(np.max(np.abs(a-ref)) for a in energies[1:])
    for j,(t,E) in enumerate(zip(ts,energies)):
        im=axs[0,j].imshow(E.T,origin='lower',extent=[0,2*np.pi,0,2*np.pi],vmin=0,vmax=scale,cmap='viridis')
        axs[0,j].set_title(f'tracked oscillatory packet, t={t:.2f}')
        im2=axs[1,j].imshow((E-ref).T,origin='lower',extent=[0,2*np.pi,0,2*np.pi],vmin=-delta,vmax=delta,cmap='coolwarm')
        axs[1,j].set_title('difference from reference')
        for i in [0,1]:axs[i,j].set_xlabel('x');axs[i,j].set_ylabel('y')
    fig.colorbar(im,ax=axs[0,:],shrink=.7,label='packet-averaged |B|²')
    fig.colorbar(im2,ax=axs[1,:],shrink=.7,label='Δ packet energy')
    fig.savefig(out/'figure9_reconstructed.png',dpi=170);fig.savefig(out/'figure9_reconstructed.pdf');plt.close(fig)
    with open(out/'figure9_diagnostics.csv','w',newline='') as f:
        w=csv.writer(f);w.writerow(['t','lambda1_real','lambda2_real','orthogonality_error']);w.writerows(lines)
    np.savez_compressed(out/'figure9_energy_data.npz',t=ts,energy=np.array(energies),kmax=args.kmax,rm=args.rm)
if __name__=='__main__':main()
