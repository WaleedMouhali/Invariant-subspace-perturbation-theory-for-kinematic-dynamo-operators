"""Independent small-matrix checks of the central Grassmann--Sylvester relation."""
import numpy as np
from scipy.linalg import solve_sylvester, subspace_angles

def check():
    rng=np.random.default_rng(20260804)
    n,r=8,2
    A11=np.array([[0.1,-1.0],[1.0,0.1]],dtype=complex)
    A22=np.diag([-1.0,-1.3,-1.6,-1.9,-2.2,-2.5]).astype(complex)
    A12=rng.standard_normal((r,n-r))*0.3
    A0=np.block([[A11,A12],[np.zeros((n-r,r)),A22]])
    dA=rng.standard_normal((n,n))*0.1
    F=dA[r:,:r]
    K=solve_sylvester(A22,-A11,-F)
    assert np.linalg.norm(A22@K-K@A11+F)<1e-12
    Q0=np.eye(n,dtype=complex)[:,:r]
    errors=[]
    for h in [1e-3,5e-4,2.5e-4]:
        vals,vecs=np.linalg.eig(A0+h*dA)
        idx=np.argsort(np.abs(vals-(0.1+1j)))[:1].tolist()+np.argsort(np.abs(vals-(0.1-1j)))[:1].tolist()
        Q,_=np.linalg.qr(vecs[:,idx]); angles=subspace_angles(Q0,Q)
        predicted=h*np.linalg.svd(K,compute_uv=False)
        errors.append(abs(np.linalg.norm(angles)-np.linalg.norm(predicted)))
    assert errors[2]<errors[1]<errors[0],errors
    print('PASS: Sylvester residual, first-order Grassmann distance; absolute errors:',errors)
if __name__=='__main__':check()
