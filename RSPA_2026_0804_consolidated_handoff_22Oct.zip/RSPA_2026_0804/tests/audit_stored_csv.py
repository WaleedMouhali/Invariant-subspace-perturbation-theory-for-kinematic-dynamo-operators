"""Check numerical identities in the RECOVERED CSV, not independent re-execution."""
from pathlib import Path
import csv,math
p=Path(__file__).resolve().parents[1]/'data/kmax4/abc_induction_diffusion_closure.csv'
rows=list(csv.DictReader(p.open()))
assert rows
for row in rows:
    v={k:float(x) for k,x in row.items() if k!='direction'}
    assert math.isclose(v['VG']**2,v['VG2'],rel_tol=1e-9)
    assert math.isclose(v['E_ind']+v['E_diff']+v['E_cross'],v['VG2'],rel_tol=1e-8,abs_tol=1e-10)
    assert v['eps_F']<1e-8 and v['eps_K']<1e-8 and v['eps_E']<1e-8
print(f'PASS: {len(rows)} stored directions pass algebraic CSV audit (not independent rerun)')
