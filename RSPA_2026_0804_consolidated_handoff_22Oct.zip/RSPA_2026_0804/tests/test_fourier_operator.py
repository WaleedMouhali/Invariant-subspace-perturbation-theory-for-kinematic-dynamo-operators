"""Cheap reproducible checks for ABC Fourier discretisation."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import numpy as np
from abc_induction_diffusion_rebuild import build_fourier_system,abc_fourier_coefficients
cs=abc_fourier_coefficients(1.,1.,1.)
for q,u in cs.items():
    assert np.allclose(cs[tuple(-x for x in q)],np.conj(u))
    assert abs(np.dot(q,u))<1e-13
s=build_fourier_system(1)
assert s.n==52
assert (s.D.diagonal().real<0).all()
assert (s.CA.nnz>0 and s.CB.nnz>0 and s.CC.nnz>0)
print('PASS: ABC Fourier coefficients real-field symmetry, solenoidal condition, Kmax=1 assembly')
