#!/usr/bin/env python3
"""Track the same ABC oscillatory eigenbranch and solve Re(lambda)=0 at each perturbation.
This tracks an eigenbranch, not necessarily the globally leading dynamo threshold.
"""
import argparse,csv,sys
from pathlib import Path
import numpy as np
from scipy.optimize import brentq
from scipy.sparse.linalg import eigs
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from abc_induction_diffusion_rebuild import build_fourier_system,induction_operator,leading_eigs

def main():
 p=argparse.ArgumentParser();p.add_argument('--kmax',type=int,default=3);p.add_argument('--rm0',type=float,default=23.812824);p.add_argument('--h',nargs='+',type=float,default=[.001,.002]);p.add_argument('--outdir',default='outputs/tracked_neutral');a=p.parse_args()
 s=build_fourier_system(a.kmax);d=np.array([1.,-1.,0.])/np.sqrt(2)
 def spectrum(t,rm):
  M=induction_operator(s,*(np.ones(3)+t*d),rm)
  vals,vecs=eigs(M,k=4,sigma=1j*0.4,tol=1e-9,maxiter=15000)
  ix=np.argsort(vals.real)[::-1];vals=vals[ix];vecs=vecs[:,ix]
  return vals,vecs
 v0,q0=spectrum(0,a.rm0);indices=np.where(v0.imag>1e-5)[0];j=indices[np.argmax(v0[indices].real)];l0=v0[j];q0=q0[:,j]
 def selected(t,rm):
  vals,vecs=spectrum(t,rm);ii=np.where(vals.imag>1e-5)[0]
  overlaps=np.abs(vecs[:,ii].conj().T@q0)
  distances=np.abs(vals[ii]-l0)/max(1.,abs(l0))
  k=ii[np.argmin(distances+1-overlaps)]
  return vals[k],float(abs(np.vdot(q0,vecs[:,k]))),float(vals[0].real)
 def neutral(t):
  lo=a.rm0*.93;hi=a.rm0*1.07
  f=lambda rm:selected(t,rm)[0].real
  if f(lo)*f(hi)>0:raise RuntimeError('Tracked branch not bracketed: '+str(t))
  rm=brentq(f,lo,hi,xtol=2e-9)
  lam,overlap,lead=selected(t,rm)
  return rm,lam,overlap,lead
 rows=[]
 for h in a.h:
  minus=neutral(-h);plus=neutral(h)
  deriv=(plus[0]-minus[0])/(2*h);second=(plus[0]+minus[0]-2*a.rm0)/(h*h)
  print(f'h={h:g}, Rm(-h)={minus[0]:.9f}, Rm(+h)={plus[0]:.9f}, dRm/dt={deriv:.4e}, overlaps={minus[2]:.6f},{plus[2]:.6f}',flush=True)
  rows.append([h,minus[0],plus[0],deriv,second,minus[1].real,plus[1].real,minus[2],plus[2],minus[3],plus[3]])
 out=Path(a.outdir);out.mkdir(parents=True,exist_ok=True)
 with (out/'tracked_neutral.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['h','rm_minus','rm_plus','centered_dRm_dt','second_derivative_approx','tracked_growth_minus','tracked_growth_plus','overlap_minus','overlap_plus','global_leading_growth_minus','global_leading_growth_plus']);w.writerows(rows)
if __name__=='__main__':main()
