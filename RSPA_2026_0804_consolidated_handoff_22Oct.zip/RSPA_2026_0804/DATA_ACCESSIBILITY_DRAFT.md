# Data accessibility statement — draft, conditional on public deposit

Source code, selected numerical data and plotting scripts supporting the study are available in [repository URL and DOI to be inserted after deposit]. The repository includes the recovered ABC Fourier–Galerkin implementation, numerical validation tests and documented reconstructions. Reproduction coverage and limitations are documented in `FIGURE_REPRODUCIBILITY_MATRIX.md` and `SUBMISSION_READINESS.md`.

IMPORTANT: This statement cannot be represented as satisfying complete replication of all published results until the outstanding numerical experiments are reproduced and checked. Update both the manuscript and this statement after completing the missing tests.
