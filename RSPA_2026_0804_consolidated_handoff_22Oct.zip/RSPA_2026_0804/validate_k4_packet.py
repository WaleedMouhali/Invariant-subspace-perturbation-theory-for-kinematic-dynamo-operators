#!/usr/bin/env python3
"""Independent K=4 packet tracking at fixed Rm; no global-threshold claim.

Selects the conjugate pair near a user-defined complex spectral shift and
compares orthogonal rank-two projectors. Fails loudly if a pair is not found.
"""
import argparse,csv
from pathlib import Path
import numpy as np
from scipy.sparse.linalg import eigs
from scipy.linalg import orth
from src.abc_induction_diffusion_rebuild import build_fourier_system,induction_operator

def select_pair(M,omega,ref=None,k=10):
    vp,wp=eigs(M,k=k,sigma=1j*omega,tol=1e-9,maxiter=20000)
    vn,wn=eigs(M,k=k,sigma=-1j*omega,tol=1e-9,maxiter=20000)
    candidates=[]
    for i,v in enumerate(vp):
        if v.imag<=1e-7:continue
        j=int(np.argmin(abs(vn-np.conj(v))))
        if abs(vn[j]-np.conj(v))>1e-5:continue
        Q=orth(np.column_stack((wp[:,i],wn[:,j])))
        if Q.shape[1]!=2:continue
        score=float(np.linalg.norm(Q.conj().T@ref,'fro')**2/2) if ref is not None else float(v.real)
        candidates.append((score,v,vn[j],Q))
    if not candidates:raise RuntimeError('No resolved conjugate pair; inspect spectrum and shift')
    return max(candidates,key=lambda x:x[0])

def main():
    p=argparse.ArgumentParser();p.add_argument('--kmax',type=int,default=4);p.add_argument('--rm',type=float,default=8.95117);p.add_argument('--omega',type=float,default=.4);p.add_argument('--h',type=float,default=.001);p.add_argument('--k',type=int,default=12);p.add_argument('--out',default='outputs/k4_packet_check.csv');a=p.parse_args()
    s=build_fourier_system(a.kmax);direction=np.array([1.,-1.,0.])/np.sqrt(2)
    def solve(t,ref=None):
        abc=np.ones(3)+t*direction
        M=induction_operator(s,*abc,a.rm)
        return select_pair(M,a.omega,ref,k=a.k)
    _,lam0,conj0,Q0=solve(0)
    records=[]
    for t in [-a.h,0.,a.h]:
        _,lam,conjlam,Q=solve(t,Q0)
        overlap=float(np.linalg.norm(Q.conj().T@Q0,'fro')**2/2)
        chord=float(np.sqrt(max(0,2-overlap*2)))
        records.append((t,lam.real,lam.imag,conjlam.real,conjlam.imag,overlap,chord))
        print(f't={t:+.5g} lambda={lam:.9g} overlap={overlap:.9f} chord={chord:.8g}',flush=True)
    deriv=(records[-1][1]-records[0][1])/(2*a.h)
    print(f'fixed-Rm centered growth derivative: {deriv:+.6e}; reference growth={lam0.real:+.6e}')
    out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['t','lambda_real','lambda_imag','conjugate_real','conjugate_imag','packet_overlap','projector_chord']);w.writerows(records)
    print('Saved',out)
if __name__=='__main__':main()
