# RSPA-2026-0804 — numerical reproducibility candidate (INCOMPLETE)

**Manuscript:** *Invariant-subspace perturbation theory for kinematic dynamo operators*.

**Important:** This is a **submission candidate under audit**, **not yet a complete code-and-data archive** for all results in the manuscript. Do not describe it to the editor as complete.

## Provenance
The ABC Python script and its Kmax=4 CSV/Figure 7 output were recovered from earlier research files. The generic validation and audit tests in this package were reconstructed on 17 October 2026. No missing experimental data or figure data were fabricated.

## Contents
- `src/abc_induction_diffusion_rebuild.py`: ABC induction Fourier–Galerkin, neutral-branch threshold gradient, rank-2 packet, Sylvester response, induction–diffusion decomposition.
- `data/kmax4/`: **previously stored** numerical CSV for seven directions.
- `figures/`: previously stored Figure 7 reproduction.
- `tests/`: deterministic small-matrix Sylvester test, Fourier coefficient/assembly smoke test, and stored-CSV identity audit.
- `reports/`: test outputs and unresolved reproducibility checklist.
- `manuscript/`: reference manuscript used for audit.

## Installation
Python 3.10 or newer, NumPy, SciPy, Matplotlib.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python run_smoke_tests.py
```

## Regenerate ABC decomposition (expensive)

```bash
python src/abc_induction_diffusion_rebuild.py --kmax 4 --A 1 --B 1 --C 1 --rm-min 1 --rm-max 1000 --rm-scan 80 --outdir outputs/kmax4
```

This performs a neutral-branch scan and may take substantial CPU time; it is **not** part of the smoke test. The code's first-crossing selection and eigenpacket isolation must be audited against the manuscript before claiming agreement. Supplying `--rm` bypasses the neutral search and does **not** certify that value is neutral.

## What the tests mean
`run_smoke_tests.py` checks basic mathematical and data consistency, **not** reproduction of all manuscript plots. Stored CSV closure is algebraic and not independent validation.

## Reproducibility status
See `reports/COVERAGE.md`. Figures 2–6 and 8–9, convergence at Kmax=3–6, exact-neutral recalculation, and numerical environment documentation are **not yet fully reproduced**.

## Licensing and public archive
No software license is granted in this candidate. The authors must select an appropriate license and archive a verified release on a public repository before providing its URL/DOI to the journal.

## Additional reconstructed numerical diagnostics (17 October 2026)

The following scripts produce genuine new calculations, **not** pixel-identical or parameter-identical reproductions of manuscript Figures 8 and 9:

```bash
python reconstruct_channels.py --kmax 2 --rm 8.95117 --outdir outputs/channels
python reconstruct_figure9.py --kmax 3 --rm 23.8128 --outdir outputs/figure9
```

Outputs and the detailed limitations are in `outputs/` and `reports/NEW_RESULTS_AND_LIMITATIONS.md`. These calculations have been executed. The channel decomposition closes to machine precision, but is **off-neutral at Kmax=2**. The spatial reconstruction tracks a selected oscillatory packet at fixed Rm rather than following an exact neutral branch. **Do not deposit this archive as a complete reproduction of the published manuscript yet.**

## Additional reproducibility audit (18 October 2026)

Run `python audit_reconstructed_outputs.py` to check the stored singular-channel
energy decomposition, tracked conjugate-pair eigenvalue consistency, and
orthogonality of the spatial packet. This writes `SHA256SUMS.json` for the
files present in this working package. The test **explicitly confirms** that
the perturbed Figure 9 states are not on a neutral branch; it is not a
substitute for a full neutral-branch reconstruction.

## One command per numerical figure (October 18 update)

`python figure_2.py` through `python figure_9.py` are provided, along with `python regenerate_figures.py --figure all`. Figure 7 recomputation requires `python figure_7.py --include-expensive`. **Read `FIGURE_REPRODUCIBILITY_MATRIX.md` before using these results in a submission.** The figure entry points 2–5 are demonstrative analogues, not exact manuscript reproductions. The runner may take several minutes for the ABC calculations.

## New: branch-aware symmetry diagnostic

```bash
OPENBLAS_NUM_THREADS=1 python track_packet_symmetry.py --kmax 3 --rm 23.812824 --h 0.002 0.001
```

This writes `outputs/packet_symmetry/packet_symmetry_fixed_rm.csv`. The test tracks an oscillatory eigenmode at fixed Rm and must not be confused with neutral-threshold continuation. See `reports/PACKET_SYMMETRY_CHECK.md`.

## Tracked neutral branch (18 October 2026)

Run `OPENBLAS_NUM_THREADS=1 python track_neutral_packet.py --h 0.001 0.002` to reproduce the new Kmax=3 tracked neutral-branch CSV and plot (see `reports/TRACKED_NEUTRAL_BRANCH.md`). This is a **partial validation**, not the final journal package.

### Independent Kmax=4 symmetry / Grassmann check

```bash
OPENBLAS_NUM_THREADS=1 python validate_k4_packet.py --kmax 4 --rm 8.95117 --omega 0.4 --h 0.001
```

The script independently computes conjugate eigenvectors using separate positive and negative spectral shifts, tracks the rank-two orthogonal packet, and saves `outputs/k4_packet_check.csv`. This is a fixed-Rm validation, not an exact reproduction of every manuscript figure. Consult `FIGURE_REPRODUCIBILITY_MATRIX.md` before citing reproduction coverage.
