#!/usr/bin/env python3
"""
abc_induction_diffusion_rebuild.py

Clean-room rebuild of the induction/diffusion decomposition used in the
Grassmann-response analysis of the ABC dynamo.

Main purpose
------------
For every perturbation direction a = (a_A,a_B,a_C), verify numerically that

    F = F_ind + F_diff
    K = K_ind + K_diff
    ||K||_F^2 = ||K_ind||_F^2 + ||K_diff||_F^2
                + 2 Re <K_ind,K_diff>_F

using ONE AND THE SAME neutral operator, invariant packet, projector,
reduced block A11 and Sylvester response operator.

The code builds the divergence-free Fourier-Galerkin ABC induction operator
from scratch.  It avoids constructing Q_perp explicitly: the Sylvester
problem is solved directly in the orthogonal complement of the selected
packet.

Requirements
------------
numpy, scipy, matplotlib

Example
-------
python abc_induction_diffusion_rebuild.py --kmax 4 --A 1 --B 1 --C 1

Outputs
-------
abc_induction_diffusion_closure.csv
figure7_abc_induction_diffusion_rebuilt.pdf
figure7_abc_induction_diffusion_rebuilt.png
"""

import argparse
import csv
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import scipy.linalg as la
import scipy.sparse as sp
import scipy.sparse.linalg as spla
import scipy.optimize as opt
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------
# Fourier basis
# ---------------------------------------------------------------------

def canonical_polarisation(k):
    """Return a 3x2 orthonormal basis of the plane orthogonal to k."""
    k = np.asarray(k, dtype=float)
    kn = la.norm(k)
    if kn == 0:
        raise ValueError("k=0 has no solenoidal polarisation basis")
    khat = k / kn

    # Pick a reference axis not almost parallel to k.
    refs = np.eye(3)
    ref = refs[np.argmin(np.abs(refs @ khat))]
    e1 = np.cross(khat, ref)
    e1 /= la.norm(e1)
    e2 = np.cross(khat, e1)
    e2 /= la.norm(e2)
    return np.column_stack((e1, e2)).astype(complex)


def wavevectors(kmax):
    ks = []
    for i in range(-kmax, kmax + 1):
        for j in range(-kmax, kmax + 1):
            for k in range(-kmax, kmax + 1):
                if (i, j, k) != (0, 0, 0):
                    ks.append((i, j, k))
    return ks


def abc_fourier_coefficients(A, B, C):
    """
    Fourier coefficients u_q of the real ABC velocity field:
      u_x = A sin z + C cos y
      u_y = B sin x + A cos z
      u_z = C sin y + B cos x
    with exp(i q.x) convention.
    """
    coeff = {}

    def add(q, vec):
        q = tuple(q)
        coeff[q] = coeff.get(q, np.zeros(3, complex)) + np.asarray(vec, complex)

    # A sin z in ux, A cos z in uy
    add((0, 0, +1), [-1j*A/2,  A/2, 0])
    add((0, 0, -1), [+1j*A/2,  A/2, 0])

    # B sin x in uy, B cos x in uz
    add((+1, 0, 0), [0, -1j*B/2, B/2])
    add((-1, 0, 0), [0, +1j*B/2, B/2])

    # C cos y in ux, C sin y in uz
    add((0, +1, 0), [C/2, 0, -1j*C/2])
    add((0, -1, 0), [C/2, 0, +1j*C/2])

    return coeff


@dataclass
class FourierSystem:
    kmax: int
    ks: list
    index: dict
    E: dict
    D: sp.csr_matrix
    CA: sp.csr_matrix
    CB: sp.csr_matrix
    CC: sp.csr_matrix

    @property
    def n(self):
        return self.D.shape[0]


def build_component_operator(ks, index, E, component):
    """
    Build C_A, C_B, or C_C from unit-amplitude ABC Fourier coefficients.
    Block formula:
      b_k_dot = sum_p E_k^* [ i k x (u_{k-p} x (E_p b_p)) ]
    """
    amp = dict(A=0.0, B=0.0, C=0.0)
    amp[component] = 1.0
    uhat = abc_fourier_coefficients(**amp)

    rows, cols, data = [], [], []

    for p in ks:
        Ep = E[p]
        pcol = 2 * index[p]

        for q, uq in uhat.items():
            k = (p[0] + q[0], p[1] + q[1], p[2] + q[2])
            if k not in index:
                continue

            Ek = E[k]
            kk = np.asarray(k, dtype=float)

            # 3x2 action on the two solenoidal polarisation columns at p
            physical = np.empty((3, 2), complex)
            for j in range(2):
                physical[:, j] = 1j * np.cross(kk, np.cross(uq, Ep[:, j]))

            block = Ek.conj().T @ physical  # 2x2
            krow = 2 * index[k]

            for a in range(2):
                for b in range(2):
                    val = block[a, b]
                    if abs(val) > 0:
                        rows.append(krow + a)
                        cols.append(pcol + b)
                        data.append(val)

    n = 2 * len(ks)
    return sp.coo_matrix((data, (rows, cols)), shape=(n, n), dtype=complex).tocsr()


def build_fourier_system(kmax):
    ks = wavevectors(kmax)
    index = {k: i for i, k in enumerate(ks)}
    E = {k: canonical_polarisation(k) for k in ks}

    diag = []
    for k in ks:
        k2 = float(k[0]**2 + k[1]**2 + k[2]**2)
        diag.extend([-k2, -k2])
    D = sp.diags(diag, dtype=complex, format="csr")

    print(f"[build] Kmax={kmax}, Fourier dimension N={2*len(ks)}")
    CA = build_component_operator(ks, index, E, "A")
    CB = build_component_operator(ks, index, E, "B")
    CC = build_component_operator(ks, index, E, "C")
    return FourierSystem(kmax, ks, index, E, D, CA, CB, CC)


# ---------------------------------------------------------------------
# Neutral branch and eigenspaces
# ---------------------------------------------------------------------

def induction_operator(sys, A, B, C, Rm):
    return A*sys.CA + B*sys.CB + C*sys.CC + (1.0/Rm)*sys.D


def leading_eigs(M, k=6, v0=None):
    vals, vecs = spla.eigs(M, k=k, which="LR", v0=v0, tol=1e-10, maxiter=10000)
    order = np.argsort(vals.real)[::-1]
    return vals[order], vecs[:, order]


def growth_rate(sys, A, B, C, Rm):
    M = induction_operator(sys, A, B, C, Rm)
    vals, _ = leading_eigs(M, k=min(6, M.shape[0]-2))
    return float(vals[0].real)


def find_neutral_rm(sys, A, B, C, rmin=1.0, rmax=1000.0, nscan=80):
    """
    Find the first sign change of the leading growth rate on a log Rm scan.
    If the desired ABC branch is not the first crossing, use --rm instead.
    """
    grid = np.geomspace(rmin, rmax, nscan)
    g = np.array([growth_rate(sys, A, B, C, rm) for rm in grid])

    print("[neutral] scanning for Re(lambda_max)=0")
    for i in range(len(grid)-1):
        if g[i] == 0 or g[i]*g[i+1] < 0:
            lo, hi = grid[i], grid[i+1]
            root = opt.brentq(lambda rm: growth_rate(sys, A, B, C, rm),
                              lo, hi, xtol=1e-10, rtol=1e-10, maxiter=100)
            print(f"[neutral] bracket [{lo:.8g}, {hi:.8g}] -> Rm_c={root:.12g}")
            return root

    raise RuntimeError(
        "No neutral crossing found. Increase --rm-max or specify --rm explicitly."
    )


def selected_packet(M, r=2):
    vals, vecs = leading_eigs(M, k=max(6, r+2))
    vals_sel = vals[:r]
    V = vecs[:, :r]
    Q, _ = la.qr(V, mode="economic")
    A11 = Q.conj().T @ (M @ Q)
    return vals_sel, Q, A11


def leading_left_vector(M, lam):
    vals_l, vecs_l = spla.eigs(M.getH(), k=6, which="LR", tol=1e-10, maxiter=10000)
    j = np.argmin(np.abs(vals_l - np.conj(lam)))
    return vecs_l[:, j]


def threshold_gradient(sys, A, B, C, Rm_c, vals_sel, Q):
    """
    First-order derivative of the neutral threshold using one leading
    eigenpair. For a conjugate neutral pair either member gives the same
    derivative of its real part up to numerical error.
    """
    # Pick one member of the leading packet; prefer Im(lambda)>=0.
    j = np.argmax(vals_sel.imag)
    lam = vals_sel[j]

    # Obtain a matching right eigenvector from the selected invariant packet
    # by diagonalising A11 inside Q.
    M = induction_operator(sys, A, B, C, Rm_c)
    A11 = Q.conj().T @ (M @ Q)
    ev11, W11 = la.eig(A11)
    jj = np.argmin(np.abs(ev11 - lam))
    v = Q @ W11[:, jj]

    w = leading_left_vector(M, lam)
    denom_lr = np.vdot(w, v)
    if abs(denom_lr) < 1e-12:
        raise RuntimeError("Left/right eigenvector pairing is ill-conditioned.")
    w = w / np.conj(denom_lr)  # now w^H v = 1

    dA_dRm = -(1.0 / Rm_c**2) * sys.D
    dlam_dRm = np.vdot(w, dA_dRm @ v)

    grads = []
    for Ci in (sys.CA, sys.CB, sys.CC):
        dlam_dalpha = np.vdot(w, Ci @ v)
        denom = np.real(dlam_dRm)
        if abs(denom) < 1e-13:
            raise RuntimeError("Neutral branch derivative is singular: Re(dlambda/dRm)≈0.")
        grads.append(-np.real(dlam_dalpha) / denom)

    return np.asarray(grads, float), lam, v, w


# ---------------------------------------------------------------------
# Sylvester response without Q_perp
# ---------------------------------------------------------------------

class ComplementOperator(spla.LinearOperator):
    """
    B = (I-P) A (I-P), represented as a LinearOperator.
    """
    def __init__(self, A, Q):
        self.A = A
        self.Q = Q
        n = A.shape[0]
        super().__init__(dtype=np.complex128, shape=(n, n))

    def proj(self, x):
        return x - self.Q @ (self.Q.conj().T @ x)

    def _matvec(self, x):
        xp = self.proj(x)
        return self.proj(self.A @ xp)


def sylvester_response_ambient(Ac, Q, A11, G, rtol=1e-11):
    """
    Solve in ambient coordinates:
        B X - X A11 = -G,
        B=(I-P)Ac(I-P),   Q^H X = 0.

    G must already lie in the orthogonal complement.
    The returned X = Q_perp K and therefore ||X||_F = ||K||_F.
    """
    # Diagonalise small A11: A11 = V diag(lam) V^{-1}
    lam, V = la.eig(A11)
    Vinv = la.inv(V)

    H = G @ V
    Bop = ComplementOperator(Ac, Q)
    n, r = G.shape
    Y = np.zeros((n, r), complex)

    for j in range(r):
        shift = lam[j]

        def mv(x):
            return Bop @ x - shift*x

        Lop = spla.LinearOperator((n, n), matvec=mv, dtype=np.complex128)
        rhs = -H[:, j]

        y, info = spla.gmres(Lop, rhs, rtol=rtol, atol=0.0,
                             restart=min(200, n), maxiter=2000)
        if info != 0:
            raise RuntimeError(f"GMRES failed for Sylvester column {j}: info={info}")

        # Remove tiny numerical packet component.
        y = y - Q @ (Q.conj().T @ y)
        Y[:, j] = y

    X = Y @ Vinv
    X = X - Q @ (Q.conj().T @ X)
    return X


def frob2(X):
    return float(np.real(np.vdot(X, X)))


def relerr(num, den, floor=1e-30):
    return float(abs(num) / max(abs(den), floor))


# ---------------------------------------------------------------------
# Directional decomposition
# ---------------------------------------------------------------------

def normalise(a):
    a = np.asarray(a, float)
    n = la.norm(a)
    if n == 0:
        raise ValueError("zero perturbation direction")
    return a/n


DEFAULT_DIRECTIONS = {
    "A":   (1, 0, 0),
    "B":   (0, 1, 0),
    "C":   (0, 0, 1),
    "A-B": (1,-1, 0),
    "A+B": (1, 1, 0),
    "A+C": (1, 0, 1),
    "B-C": (0, 1,-1),
}


def analyse_direction(sys, Ac, Q, A11, Rm_c, grad_rm, name, a):
    a = normalise(a)
    dotC = a[0]*sys.CA + a[1]*sys.CB + a[2]*sys.CC
    dotRm = float(grad_rm @ a)

    # Ambient transverse forcings G = Q_perp F = (I-P) dotA Q.
    def project_complement(X):
        return X - Q @ (Q.conj().T @ X)

    G_ind = project_complement(dotC @ Q)
    G_diff = project_complement((-(dotRm/Rm_c**2) * sys.D) @ Q)
    G_total_direct = project_complement(
        (dotC - (dotRm/Rm_c**2)*sys.D) @ Q
    )
    G_total_sum = G_ind + G_diff

    eps_F = la.norm(G_total_direct - G_total_sum, "fro") / max(
        la.norm(G_total_direct, "fro"), 1e-30
    )

    # Same Sylvester operator for all three solves.
    K_ind = sylvester_response_ambient(Ac, Q, A11, G_ind)
    K_diff = sylvester_response_ambient(Ac, Q, A11, G_diff)
    K_total = sylvester_response_ambient(Ac, Q, A11, G_total_direct)

    K_sum = K_ind + K_diff
    eps_K = la.norm(K_total - K_sum, "fro") / max(
        la.norm(K_total, "fro"), 1e-30
    )

    VG2 = frob2(K_total)
    E_ind = frob2(K_ind)
    E_diff = frob2(K_diff)
    E_cross = float(2.0*np.real(np.vdot(K_ind, K_diff)))
    E_sum = E_ind + E_diff + E_cross
    eps_E = relerr(VG2 - E_sum, VG2)

    return {
        "direction": name,
        "aA": a[0], "aB": a[1], "aC": a[2],
        "dotRm_c": dotRm,
        "VG2": VG2,
        "VG": np.sqrt(max(VG2, 0.0)),
        "E_ind": E_ind,
        "E_diff": E_diff,
        "E_cross": E_cross,
        "E_sum": E_sum,
        "eps_F": eps_F,
        "eps_K": eps_K,
        "eps_E": eps_E,
    }


# ---------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------

def save_csv(rows, path):
    fields = list(rows[0].keys())
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def make_figure(rows, outstem):
    labels = [r["direction"] for r in rows]
    Eind = np.array([r["E_ind"] for r in rows])
    Ediff = np.array([r["E_diff"] for r in rows])
    Ecross = np.array([r["E_cross"] for r in rows])
    VG2 = np.array([r["VG2"] for r in rows])

    x = np.arange(len(labels))
    width = 0.22

    fig, ax = plt.subplots(figsize=(9.0, 4.8))
    ax.bar(x-width, Eind, width, label=r"$E_{\rm ind}$")
    ax.bar(x,       Ediff, width, label=r"$E_{\rm diff}$")
    ax.bar(x+width, Ecross, width, label=r"$E_{\rm cross}$")
    ax.plot(x, VG2, "o", label=r"$V_G^2$ (direct)")

    ax.axhline(0.0, linewidth=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.set_ylabel("quadratic structural response")
    ax.set_xlabel("normalised ABC perturbation direction")
    ax.legend()
    ax.set_title("Induction–diffusion decomposition with exact closure check")
    fig.tight_layout()
    fig.savefig(str(outstem) + ".pdf", bbox_inches="tight")
    fig.savefig(str(outstem) + ".png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def print_diagnostics(rows):
    print("\nClosure diagnostics")
    print("="*88)
    print(f"{'dir':>7s} {'dotRm':>12s} {'VG':>12s} {'eps_F':>14s} {'eps_K':>14s} {'eps_E':>14s}")
    for r in rows:
        print(f"{r['direction']:>7s} {r['dotRm_c']:12.5e} {r['VG']:12.5e} "
              f"{r['eps_F']:14.5e} {r['eps_K']:14.5e} {r['eps_E']:14.5e}")
    print("="*88)
    print("Expected: eps_F ~ machine precision; eps_K and eps_E near the GMRES tolerance.")
    print("Do NOT use Figure 7 unless all three diagnostics are satisfactorily small.")


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kmax", type=int, default=4)
    ap.add_argument("--A", type=float, default=1.0)
    ap.add_argument("--B", type=float, default=1.0)
    ap.add_argument("--C", type=float, default=1.0)
    ap.add_argument("--rm", type=float, default=None,
                    help="Use this neutral Rm directly instead of scanning for a crossing.")
    ap.add_argument("--rm-min", type=float, default=1.0)
    ap.add_argument("--rm-max", type=float, default=1000.0)
    ap.add_argument("--rm-scan", type=int, default=80)
    ap.add_argument("--outdir", type=Path, default=Path("."))
    args = ap.parse_args()

    args.outdir.mkdir(parents=True, exist_ok=True)

    sys = build_fourier_system(args.kmax)

    if args.rm is None:
        Rm_c = find_neutral_rm(sys, args.A, args.B, args.C,
                               args.rm_min, args.rm_max, args.rm_scan)
    else:
        Rm_c = args.rm
        print(f"[neutral] using supplied Rm_c={Rm_c:.12g}")

    Ac = induction_operator(sys, args.A, args.B, args.C, Rm_c)
    vals_sel, Q, A11 = selected_packet(Ac, r=2)

    print("\nSelected leading packet:")
    for j, z in enumerate(vals_sel):
        print(f"  lambda[{j}] = {z.real:+.12e} {z.imag:+.12e}i")

    sep_proxy = np.min(np.abs(
        vals_sel[:, None] - leading_eigs(Ac, k=8)[0][2:][None, :]
    ))
    print(f"  simple eigenvalue-distance proxy to next computed modes: {sep_proxy:.5e}")

    grad_rm, lam, v, w = threshold_gradient(
        sys, args.A, args.B, args.C, Rm_c, vals_sel, Q
    )
    print("\nNeutral-threshold gradient:")
    print(f"  dRm_c/dA = {grad_rm[0]:+.12e}")
    print(f"  dRm_c/dB = {grad_rm[1]:+.12e}")
    print(f"  dRm_c/dC = {grad_rm[2]:+.12e}")

    rows = []
    for name, a in DEFAULT_DIRECTIONS.items():
        print(f"[direction] {name}")
        rows.append(
            analyse_direction(sys, Ac, Q, A11, Rm_c, grad_rm, name, a)
        )

    print_diagnostics(rows)

    csv_path = args.outdir / "abc_induction_diffusion_closure.csv"
    save_csv(rows, csv_path)

    figstem = args.outdir / "figure7_abc_induction_diffusion_rebuilt"
    make_figure(rows, figstem)

    # Hard safety gate.
    worst_F = max(r["eps_F"] for r in rows)
    worst_K = max(r["eps_K"] for r in rows)
    worst_E = max(r["eps_E"] for r in rows)

    print(f"\nSaved: {csv_path}")
    print(f"Saved: {figstem}.pdf")
    print(f"Saved: {figstem}.png")
    print(f"\nWorst closure errors: eps_F={worst_F:.3e}, eps_K={worst_K:.3e}, eps_E={worst_E:.3e}")

    if worst_F > 1e-9 or worst_K > 1e-8 or worst_E > 1e-8:
        raise SystemExit(
            "\nSAFETY GATE FAILED: do not use the rebuilt Figure 7 yet. "
            "Inspect the closure diagnostics above."
        )

    print("\nSAFETY GATE PASSED: induction/diffusion closure is numerically consistent.")


if __name__ == "__main__":
    main()
