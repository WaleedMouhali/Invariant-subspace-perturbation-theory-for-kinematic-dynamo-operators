#!/usr/bin/env python3
"""Independent small-amplitude symmetry check at fixed Rm, tracking a complex ABC eigenpair.
Does NOT assert reproduction of the manuscript's neutral branch or any figure.
"""
import argparse,csv,sys
from pathlib import Path
import numpy as np
import scipy.linalg as la
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from abc_induction_diffusion_rebuild import build_fourier_system, induction_operator, leading_eigs

def run(kmax,rm,amplitudes,outdir):
    s=build_fourier_system(kmax)
    direction=np.array([1.,-1.,0.])/np.sqrt(2.)
    def solve(t,reference=None):
        abc=np.ones(3)+t*direction
        vals,vecs=leading_eigs(induction_operator(s,*abc,rm),k=12)
        pos=np.where(vals.imag>1e-6)[0]
        if len(pos)==0: raise RuntimeError('No oscillatory mode in returned eigenspectrum')
        if reference is None:
            j=int(pos[np.argmax(vals[pos].real)])
        else:
            overlaps=np.abs(vecs[:,pos].conj().T@reference)
            # Nearest eigenvalue and eigenvector overlap, with explicit diagnostics
            metric=np.abs(vals[pos]-reference_lambda)/(max(1,abs(reference_lambda)))+ (1-overlaps)
            j=int(pos[np.argmin(metric)])
        return vals[j],vecs[:,j],vals
    # Select at symmetry point, track by combined eigenvalue and eigenvector overlap.
    global reference_lambda
    reference_lambda,v0,_=solve(0.)
    rows=[]
    for h in amplitudes:
        lp,vp,_=solve(+h,v0);lm,vm,_=solve(-h,v0)
        overlap_plus=float(abs(np.vdot(v0,vp)));overlap_minus=float(abs(np.vdot(v0,vm)))
        derivative=(lp.real-lm.real)/(2*h)
        curvature=(lp.real+lm.real-2*reference_lambda.real)/h**2
        rows.append([h,reference_lambda.real,reference_lambda.imag,lp.real,lm.real,lp.imag,lm.imag,derivative,curvature,overlap_plus,overlap_minus])
        print(f'h={h:g} dRe(lambda)/dt={derivative:+.6e} overlaps=({overlap_plus:.6f},{overlap_minus:.6f})',flush=True)
    out=Path(outdir);out.mkdir(parents=True,exist_ok=True)
    with (out/'packet_symmetry_fixed_rm.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['h','lambda0_real','lambda0_imag','lambda_plus_real','lambda_minus_real','lambda_plus_imag','lambda_minus_imag','centered_first_derivative','centered_second_derivative','overlap_plus','overlap_minus']);w.writerows(rows)
    return rows

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--kmax',type=int,default=3);p.add_argument('--rm',type=float,default=23.812824);p.add_argument('--h',type=float,nargs='+',default=[.002,.001]);p.add_argument('--outdir',default='outputs/packet_symmetry');a=p.parse_args()
    run(a.kmax,a.rm,a.h,a.outdir)
