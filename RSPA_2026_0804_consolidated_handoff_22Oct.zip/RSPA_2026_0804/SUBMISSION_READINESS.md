# Submission readiness — 20 October 2026

**Status: NOT FULLY REPRODUCIBLE; do not claim that every manuscript figure is independently reproduced.**

This repository contains Python entry points for numerical Figures 2–9. Figure 1 is conceptual.

- Figures 2–5: deterministic mathematical analogues, not exact manuscript experiment configurations.
- Figure 6: recovered ABC Kmax=4 CSV; regenerated plot.
- Figure 7: recovered source script and output, but costly independent rerun not certified.
- Figure 8: ABC channel validation at Kmax=2, not paper parameters.
- Figure 9: spatial validation at Kmax=3 and fixed Rm, not neutral Kmax=4 paper parameters.
- Kmax=3–6 neutral-threshold convergence table not fully independently verified.

Run `python run_smoke_tests.py` for fast checks. Run `python figure_2.py` through `python figure_6.py` to regenerate individual outputs. See `FIGURE_REPRODUCIBILITY_MATRIX.md` for remaining gaps.

Before public deposition, complete the missing exact experiments and certify numerical agreement with the paper, or clearly delimit the claims and update the manuscript.
