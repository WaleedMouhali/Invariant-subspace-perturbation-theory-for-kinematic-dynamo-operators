import argparse
_parser=argparse.ArgumentParser()
_parser.add_argument("--only", choices=["2","3","4","5","6","all"],default="all")
_SELECTED=_parser.parse_args().only
from pathlib import Path
import csv, numpy as np, scipy.linalg as la
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'figures'/'reconstructed';OUT.mkdir(parents=True,exist_ok=True)
# Deterministic invariant graph model A(t)=T(t) diag(lam) T(t)^-1, invariant graph K(t)=t K0
D=np.diag([0.1,-0.2,-1.4,-2.3]); Q0=np.eye(4)[:,:2];K0=np.array([[.7,-.2],[.3,.5]])
def packet(t,K=K0):
 X=np.vstack((np.eye(2),t*K));return la.qr(X,mode='economic')[0]
def dist(P,Q):
 s=la.svdvals(P.T@Q);return la.norm(np.arccos(np.clip(s,-1,1)))
v=la.norm(K0);ts=np.logspace(-5,-1,24)
fig,axs=plt.subplots(2,2,figsize=(10,7));ax=axs[0,0];err=[]
for t in ts:
 qp=packet(t);qm=packet(-t);# finite difference orthogonal projectors, tangent norm /sqrt2
 deriv=(qp@qp.T-qm@qm.T)/(2*t);err.append(la.norm(deriv)/np.sqrt(2)-v)
ax.loglog(ts,np.abs(err),'.-');ax.set(xlabel='step h',ylabel='absolute velocity error',title='(a) Centered finite differences')
ax=axs[0,1];ds=np.array([dist(Q0,packet(t)) for t in ts]);ax.loglog(ts,ds,'o',ms=3,label='exact');ax.loglog(ts,ts*v,'--',label='linear');ax.legend();ax.set(xlabel='parameter displacement',ylabel='Grassmann distance',title='(b) Local distance')
ax=axs[1,0];ax.bar(['internal','transverse'],[0,v]);ax.set(ylabel='Grassmann velocity',title='(c) Forcing location')
ax=axs[1,1];scales=np.linspace(.1,1.3,12);ax.plot(scales**2*v*v,scales**2*v*v,'o');ax.plot([0,max(scales**2*v*v)],[0,max(scales**2*v*v)],'--');ax.set(xlabel='direct squared velocity',ylabel='quadratic prediction',title='(d) Quadratic identity');fig.suptitle('Figure 2 analogue — reconstructed deterministic test, NOT original data');fig.tight_layout();(fig.savefig(OUT/'figure2_analogue.png',dpi=180) if _SELECTED in ('all','2') else None);plt.close(fig)
# diagonal Sylvester channels
sep=np.geomspace(.1,4,60);robust=1/np.sqrt(sep**2+4);compliant=1/sep
fig,axs=plt.subplots(1,2,figsize=(10,4));axs[0].loglog(sep,robust,label='robust channel');axs[0].loglog(sep,compliant,label='compliant channel');axs[0].legend();axs[0].set(xlabel='smallest Sylvester singular value',ylabel='response norm',title='(a) Orientation dependence');axs[1].loglog(sep,compliant,'o',ms=2,label='aligned response');axs[1].loglog(sep,1/sep,'--',label='upper bound');axs[1].legend();axs[1].set(xlabel='separation',ylabel='response/bound',title='(b) Bound saturation');fig.suptitle('Figure 3 analogue — analytic diagonal Sylvester model');fig.tight_layout();(fig.savefig(OUT/'figure3_analogue.png',dpi=180) if _SELECTED in ('all','3') else None);plt.close(fig)
# channels and finite evolution
sing=np.array([.4,.8,1.5,3]);forcing=np.array([.5,.7,.2,.3]);energy=(forcing/sing)**2
fig,axs=plt.subplots(1,2,figsize=(10,4));axs[0].bar(np.arange(1,5),energy);axs[0].set(xlabel='Sylvester channel',ylabel='channel energy',title='(a) Channel anisotropy');xx=np.linspace(0,1,80);axs[1].plot(xx,[dist(Q0,packet(x)) for x in xx],label='finite distance');axs[1].plot(xx,xx*v,'--',label='linear');axs[1].legend();axs[1].set(xlabel='family parameter',ylabel='Grassmann distance',title='(b) Finite evolution');fig.suptitle('Figure 4 analogue — reconstructed toy model');fig.tight_layout();(fig.savefig(OUT/'figure4_analogue.png',dpi=180) if _SELECTED in ('all','4') else None);plt.close(fig)
# quadratic sensitivity eigenproblem: two graph directions
G1=np.array([[1.,0],[0,.2]]);G2=np.array([[.2,.5],[-.3,.1]]);G3=np.array([[.1,-.4],[.5,.2]]);Gs=[G1,G2,G3];H=np.array([[np.sum(x*y) for y in Gs] for x in Gs]);eig,U=la.eigh(H);idx=np.argsort(eig);eig=eig[idx];U=U[:,idx]
fig,axs=plt.subplots(1,2,figsize=(10,4));axs[0].bar(np.arange(1,4),eig);axs[0].set(xlabel='ordered eigenmode',ylabel='squared optimal velocity',title='(a) Quadratic optimisation')
for j in [0,2]:
 a=U[:,j];K=sum(a[i]*Gs[i] for i in range(3));h=1e-4;observed=dist(packet(-h,K),packet(h,K))/(2*h);axs[1].scatter([np.sqrt(eig[j])],[observed],label=f'mode {j+1}')
lims=[0,max(np.sqrt(eig))*1.1];axs[1].plot(lims,lims,'--');axs[1].set(xlabel='predicted velocity',ylabel='finite-difference velocity',title='(b) Independent finite differences');axs[1].legend();fig.suptitle('Figure 5 analogue — reconstructed toy model');fig.tight_layout();(fig.savefig(OUT/'figure5_analogue.png',dpi=180) if _SELECTED in ('all','5') else None);plt.close(fig)
with open(ROOT/'data/kmax4/abc_induction_diffusion_closure.csv') as f:rows=list(csv.DictReader(f))
labels=[r['direction'] for r in rows];grad=np.array([abs(float(r['dotRm_c'])) for r in rows]);vel=np.array([float(r['VG']) for r in rows]);fig,axs=plt.subplots(1,2,figsize=(11,4));axs[0].bar(labels,grad);axs[0].set(ylabel='absolute threshold derivative',title='(a) Threshold response');axs[1].bar(labels,vel);axs[1].set(ylabel='Grassmann velocity',title='(b) Structural response')
for ax in axs:ax.tick_params(axis='x',rotation=35)
fig.suptitle('Figure 6 reconstruction — recovered ABC Kmax=4 numerical CSV');fig.tight_layout();(fig.savefig(OUT/'figure6_from_recovered_csv.png',dpi=180) if _SELECTED in ('all','6') else None);plt.close(fig)
(OUT/'PROVENANCE.md').write_text('Figures 2–5: newly generated deterministic illustrative analogues. They are NOT the original manuscript numerical experiments and must not be submitted as reproduction of those figures. Figure 6: plot of recovered Kmax=4 CSV values; visual representation may differ from manuscript. Figures 8 and 9 have separate newly reconstructed scripts, but their parameters differ from those in the manuscript.\n')
print('Generated:',*[p.name for p in sorted(OUT.glob('*.png'))])
