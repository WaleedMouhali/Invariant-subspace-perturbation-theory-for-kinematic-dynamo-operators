#!/usr/bin/env python3
"""Figure script launcher. See FIGURE_REPRODUCIBILITY_MATRIX.md for provenance."""
import argparse,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--figure',choices=['2','3','4','5','6','7','8','9','all'],default='all')
p.add_argument('--include-expensive',action='store_true',help='Run ABC Kmax=4 source reconstruction, potentially slow')
a=p.parse_args()
def run(script,*args):
    print('RUN',script,*args,flush=True)
    subprocess.run([sys.executable,str(ROOT/script),*args],cwd=ROOT,check=True)
if a.figure in ['all','2','3','4','5','6']:run('experiments_reconstructed.py','--only',a.figure if a.figure != 'all' else 'all')
if a.figure in ['all','8']:run('reconstruct_channels.py','--kmax','2','--rm','8.95117','--outdir','outputs/channels')
if a.figure in ['all','9']:run('reconstruct_figure9.py','--kmax','3','--rm','23.8128','--outdir','outputs/figure9')
if a.figure in ['all','7']:
    if not a.include_expensive:
        print('Figure 7: recovered image/CSV included; to recompute run --figure 7 --include-expensive')
    else:
        run('src/abc_induction_diffusion_rebuild.py','--kmax','4','--A','1','--B','1','--C','1','--rm-min','1','--rm-max','1000','--rm-scan','80','--outdir','outputs/kmax4')
