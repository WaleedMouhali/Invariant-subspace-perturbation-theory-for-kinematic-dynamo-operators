from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent
for name in ['test_generic_sylvester.py','test_fourier_operator.py','audit_stored_csv.py']:
    subprocess.run([sys.executable,str(r/'tests'/name)],check=True)
