# RSPA-2026-0804 — Consolidated handoff (22 October 2026)

This ZIP consolidates the available recovered numerical code, stored data, plotting scripts, and explicit provenance notes. It is a **complete handoff of the recovered working materials**, NOT a certified complete reproduction of the submitted article.

## Verified locally
- `python run_smoke_tests.py` succeeds: generic Sylvester tangent, ABC Fourier assembly, stored CSV algebraic closure.
- `python regenerate_figures.py --figure 2` and analogous entry points execute reconstructed deterministic examples (not the paper's exact tests).
- The ZIP archive is CRC-verified and contains the original recovered `src/abc_induction_diffusion_rebuild.py`.

## Not yet verified against the submitted paper
- Figures 2–5: only illustrative analogues, not original numerical experiment parameters.
- Figure 6: stored ABC data plotted in a newly designed layout; not an exact figure match.
- Figure 7: original recovered script and outputs, no fresh full Kmax=4 rerun certified in this handoff.
- Figure 8: reduced-resolution Kmax=2 reconstruction.
- Figure 9: Kmax=3 reconstruction at fixed Rm rather than the paper's neutral Kmax=4 configuration.
- Full Kmax=3–6 convergence table not independently reproduced.

## Publication warning
Do not state to the editor that this ZIP permits exact independent regeneration of all figures. Either complete these tests or disclose the limitations and ask the journal whether a staged deposit is acceptable.
