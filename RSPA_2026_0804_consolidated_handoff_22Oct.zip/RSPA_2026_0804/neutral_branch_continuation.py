#!/usr/bin/env python3
"""Neutral-branch ABC continuation; freshly computed validation, not manuscript figure."""
import sys,csv,argparse
from pathlib import Path
import numpy as np
from scipy.optimize import brentq
import scipy.linalg as la
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from abc_induction_diffusion_rebuild import build_fourier_system, induction_operator, leading_eigs
from reconstruct_figure9 import energy

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--kmax',type=int,default=3);ap.add_argument('--outdir',default='outputs/neutral_continuation_k3');args=ap.parse_args()
    out=Path(args.outdir);out.mkdir(parents=True,exist_ok=True)
    s=build_fourier_system(args.kmax); direction=np.array([1.,-1.,0.])/np.sqrt(2)
    rows=[]; maps=[]; P0=None
    for t in (0.,.01,.02):
        abc=np.ones(3)+t*direction
        def growth(rm):
            vals,_=leading_eigs(induction_operator(s,*abc,rm),k=6)
            return float(vals[0].real)
        rm=brentq(growth,22.,26.,xtol=1e-8)
        vals,vecs=leading_eigs(induction_operator(s,*abc,rm),k=8)
        Q,_=la.qr(vecs[:,:2],mode='economic');P=Q@Q.conj().T
        if P0 is None:P0=P
        chord=la.norm(P-P0,'fro')/np.sqrt(2)
        maps.append(energy(s,Q,nxy=65))
        rows.append([t,rm,vals[0].real,vals[1].real,vals[0].imag,vals[1].imag,chord,la.norm(Q.conj().T@Q-np.eye(2))])
        print('t',t,'Rm_c',rm,'eig',vals[:2],'chord',chord,flush=True)
    with open(out/'neutral_continuation.csv','w',newline='') as f:
        w=csv.writer(f);w.writerow(['t','rm_c','lambda1_real','lambda2_real','lambda1_imag','lambda2_imag','projector_chord','orthogonality_error']);w.writerows(rows)
    np.savez_compressed(out/'neutral_packet_energy.npz',energy=np.asarray(maps),t=[0,.01,.02],rm_c=[r[1] for r in rows])
    fig,axes=plt.subplots(1,3,figsize=(12,3.5),constrained_layout=True)
    vmax=max(x.max() for x in maps)
    for i,(ax,e) in enumerate(zip(axes,maps)):
        ax.imshow(e.T,origin='lower',extent=[0,2*np.pi,0,2*np.pi],vmin=0,vmax=vmax)
        ax.set_title('t=%.2f; Rm=%.6f'%(rows[i][0],rows[i][1]));ax.set_xlabel('x');ax.set_ylabel('y')
    fig.savefig(out/'neutral_packet_spatial.png',dpi=160);fig.savefig(out/'neutral_packet_spatial.pdf')
if __name__=='__main__':main()
