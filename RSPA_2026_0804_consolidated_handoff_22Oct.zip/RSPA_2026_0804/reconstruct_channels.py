#!/usr/bin/env python3
"""Actual Sylvester singular-channel decomposition on a reduced ABC truncation.
Diagnostic only: does not reproduce Kmax=4 manuscript Figure 8.
"""
import sys,argparse,csv
from pathlib import Path
import numpy as np, scipy.linalg as la
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from abc_induction_diffusion_rebuild import build_fourier_system, induction_operator, selected_packet

def main():
    p=argparse.ArgumentParser();p.add_argument('--kmax',type=int,default=2);p.add_argument('--rm',type=float,default=8.95117);p.add_argument('--outdir',default='outputs/channels');args=p.parse_args()
    out=Path(args.outdir);out.mkdir(parents=True,exist_ok=True)
    s=build_fourier_system(args.kmax)
    M=induction_operator(s,1,1,1,args.rm).toarray();ev,Q,A11=selected_packet(induction_operator(s,1,1,1,args.rm),r=2)
    U=la.null_space(Q.conj().T)
    B=U.conj().T@M@U
    F=U.conj().T@((s.CA-s.CB)@Q)/np.sqrt(2)
    r=2;n=B.shape[0]
    # Column-major vectorisation: vec(BK-KA11) = (I⊗B-A11^T⊗I)vec(K)
    S=np.kron(np.eye(r),B)-np.kron(A11.T,np.eye(n))
    u,sigma,vh=la.svd(S,full_matrices=False)
    f=F.reshape(-1,order='F')
    coeff=u.conj().T@f
    energy=np.abs(coeff/sigma)**2
    order=np.argsort(energy)[::-1];energies=energy[order]
    exact=np.linalg.norm(la.solve(S,-f))**2
    print('Kmax',args.kmax,'Rm',args.rm,'eigenvalues',ev,'total',exact,'channel sum',sum(energy),'error',abs(sum(energy)-exact)/exact)
    fig,ax=plt.subplots(1,2,figsize=(10,4))
    ax[0].bar(np.arange(1,13),energies[:12]/exact);ax[0].set(xlabel='channel rank',ylabel='fraction of total response',title='Actual Sylvester singular channels')
    ax[1].plot(np.arange(1,21),np.cumsum(energies[:20])/exact,'o-');ax[1].set(xlabel='retained channels',ylabel='cumulative response fraction',ylim=(0,1.05))
    fig.suptitle(f'ABC reduced diagnostic Kmax={args.kmax}; Rm={args.rm} (not manuscript Fig. 8)')
    fig.tight_layout();fig.savefig(out/'sylvester_channels_k2.png',dpi=170);fig.savefig(out/'sylvester_channels_k2.pdf');plt.close(fig)
    with open(out/'sylvester_channel_energies.csv','w',newline='') as fp:
        w=csv.writer(fp);w.writerow(['rank','energy','singular_value','fraction']);w.writerows((i+1,energy[j],sigma[j],energy[j]/exact) for i,j in enumerate(order))
if __name__=='__main__':main()
