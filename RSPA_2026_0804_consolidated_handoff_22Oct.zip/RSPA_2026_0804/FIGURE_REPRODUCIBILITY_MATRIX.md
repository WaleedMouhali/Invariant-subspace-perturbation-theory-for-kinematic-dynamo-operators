# Figure-by-figure provenance and reproduction status

**CRITICAL: This is NOT yet a fully validated manuscript-reproduction package.** The scripts are executable entry points; that fact alone does not imply agreement with the paper.

| Figure | Entry point | Actual status |
|---|---|---|
| 1 | none | Conceptual schematic, not a numerical figure |
| 2 | `figure_2.py` | Reconstructed deterministic analogue; not original experiment |
| 3 | `figure_3.py` | Reconstructed deterministic analogue; not original experiment |
| 4 | `figure_4.py` | Reconstructed deterministic analogue; not original experiment |
| 5 | `figure_5.py` | Reconstructed deterministic analogue; not original experiment |
| 6 | `figure_6.py` | Plot regenerated from recovered Kmax=4 CSV; presentation may differ |
| 7 | `figure_7.py --include-expensive` | Recovered ABC source and original stored outputs; expensive independent rerun NOT certified |
| 8 | `figure_8.py` | New ABC Sylvester channel calculation at Kmax=2, off-neutral; not paper's exact figure |
| 9 | `figure_9.py` | New ABC spatial reconstruction at Kmax=3, fixed Rm; not paper's exact figure |

The manuscript's Kmax=3–6 threshold-convergence table has not been independently reproduced. Branch switching in the neutral-continuation pilot makes an unqualified claim of threshold stationarity unsafe until packet tracking is checked. No public DOI has been assigned.

Additional validation: `track_packet_symmetry.py` checks symmetry of the continuously selected oscillatory eigenvalue at fixed Rm and Kmax=3; see `reports/PACKET_SYMMETRY_CHECK.md`. This does **not** upgrade any figure's status to exact reproduction.

## Additional independent Kmax=4 check (18 October 2026)

`validate_k4_packet.py` independently verifies the stationary first-order growth rate and nonzero Grassmann rotation for the ABC oscillatory packet at fixed Rm=8.95117, Kmax=4. The observed chord/h is 3.8128215, consistent with the manuscript's 3.81283. See `reports/K4_PACKET_INDEPENDENT_2026_10_18.md`. **This does not change the incomplete status of figures 2–5, 8, 9 or of full neutral-branch convergence.**
